########################################################################################################################
#                                                                                                                      #
#                                             UBER ASSIGNMENT                                                          #
#                                                                                                                      #
# Understanding data:                                                                                                  #
# Uber data set contains details about requests made for car service only for two pickup points Airport & city. Request#
# Id is a unique field for each record. Diver Id provides identification of the driver who provides service. Status    #
# field have details like whether the request got cancelled or trip completed or no car avialable(which means cars are #
# not available to provide service). Request timestamp conatins time stamp when the request was placed and drop time   #
# stamp is the time stamp when the trip completed.                                                                     #
#                                                                                                                      #
########################################################################################################################
# Data descripencies found in data set                                                                                 #
# 1. Request.timestamp and Drop.timestamp are date fields but have dates in different formats in different rows        #
#    a. dates in format d/m/Y H:M                                                                                      #
#    b. dates in format d-m-Y H:M:S                                                                                    #
#                                                                                                                      #
########################################################################################################################
# Assumptions made:                                                                                                    #
# Demand - calculated as total number of request placed                                                                #
# Supply - service provided or requests with "Trip completed" status                                                   #
# Supply actually available  - service provided(Trip Completed") + Service cancelled("Cancelled")                      #
# Graphs used:                                                                                                         #
# Most of plots are done histogram as histogram is the most commonly used graph to show frequency distributions or     #
# univariate analysis. For bivariate analysis geom_point & geom_line graphs are used                                   #
#                                                                                                                      #
########################################################################################################################
# Loading the CSV data set to R                                                                                        #
########################################################################################################################
uber_data_1 <- read.csv("Uber Request Data.csv",stringsAsFactors = F)
uber_data <- read.csv("Uber Request Data.csv",stringsAsFactors = F)

# Declare libraries used                                                                                               #
########################################################################################################################
library(dplyr)     
library(lubridate) # for date transformation
library(ggplot2)   # for plotting data 
library(gridExtra) # using gridExtra for plotting multiple graphs in single page

########################################################################################################################
# Data cleaning:                                                                                                       #
# 1.Basic validations of data set                                                                                      #
# 2.change date format of all the rows of column Request.timestamp and Drop.timestamp in to single format              #
#   Y-m-d H:M:S                                                                                                        #
########################################################################################################################

# 1. checking for blank values "" in any of the fields of dataset
sapply(uber_data, function(x) length(which(x == "")))

# Returns 0 
#Request.id      Pickup.point         Driver.id            Status Request.timestamp    Drop.timestamp 
#      0                 0                 0                 0                 0                 0 

# 2. check for NA values and if the NA values are valid or not

sum(is.na(uber_data)) #Returns 6564 which total number of NAs in multiple columns

#checking individual fields
sapply(uber_data, function(x) length(which(is.na(x))))

#Returns
# Request.id      Pickup.point         Driver.id            Status Request.timestamp    Drop.timestamp 
#       0                 0              2650                 0                 0              3914 

sum(is.na(uber_data$Driver.id))         #Returns 2650 which should be equal to number of records 
                                        #where status is "No cars available".

nrow(uber_data[ uber_data$Status == "No Cars Available",]) #Returns 2650 

sum(is.na(uber_data$Drop.timestamp))    #Returns 3914 which should be equal to number of records
                                        #where status not equal to "Trip Completed".

nrow(uber_data[ uber_data$Status != "Trip Completed",]) #Returns 3914

#sum of 2650 & 3914 is 6564 which evaluates number of valid NAs in dataset

# 3. look for duplicate values of the key field
sum(duplicated(uber_data$Request.id)) #Returns 0 

# 4. Checking for upper case & lower case irregularities in character fields 

#For Pickup.point field, levels are "Airport" & "City"

uber_data$Pickup.point <- as.factor(uber_data$Pickup.point)
summary(uber_data$Pickup.point)

#Returns
#Airport    City 
#  3238    3507 

#For Status field, levels are  "Trip Completed","No Cars Available"& "Cancelled"

uber_data$Status <- as.factor(uber_data$Status)
summary(uber_data$Status)

#Returns
#Cancelled No Cars Available    Trip Completed 
#1264              2650              2831 

#Changing Request timestamp and Drop timestamp into required format

uber_data$Request.timestamp <- parse_date_time(uber_data$Request.timestamp, c("dmy_HMS", "dmy_HM"), tz="")
uber_data$Drop.timestamp    <- parse_date_time(uber_data$Drop.timestamp, c("dmy_HMS", "dmy_HM"), tz="")

#uber_data$Request.timestamp <- as.POSIXct(uber_data$Request.timestamp, format = "%y-%m-%d %H:%M:%S")
#uber_data$Drop.timestamp    <- as.POSIXct(uber_data$Drop.timestamp, format = "%y-%m-%d %H:%M:%S")

# From the data extracting day, hour and minute for request and drop time stamp

uber_data$Request_day      <- format(uber_data$Request.timestamp, "%d")
uber_data$Request_hour     <- format(uber_data$Request.timestamp, "%H")
uber_data$Request_minute   <- format(uber_data$Request.timestamp, "%M")

# classifying timestamp into different time slots of Request timestamp

uber_data$RQ_timeslots[uber_data$Request_hour >= '00' & uber_data$Request_hour <= '03' ]  <- "Early morning"
uber_data$RQ_timeslots[uber_data$Request_hour >= '04' & uber_data$Request_hour <= '10']   <- "Morning"
uber_data$RQ_timeslots[uber_data$Request_hour > '10' & uber_data$Request_hour <= '15' ]   <- "Noon"
uber_data$RQ_timeslots[uber_data$Request_hour > '15' & uber_data$Request_hour <= '22' ]   <- "Evening"
uber_data$RQ_timeslots[uber_data$Request_hour > '22' & uber_data$Request_hour < '24' ]    <- "Late evening"

# Subsetting data for "cancelled" and "No car available" value of Status field for Pickup.point "Airport" & "City"

uber_data_CA_Air   <- subset(uber_data, Status == "Cancelled" & Pickup.point == "Airport") 
uber_data_CA_City  <- subset(uber_data, Status == "Cancelled" & Pickup.point == "City") 
uber_data_NCA_Air  <- subset(uber_data, Status == "No Cars Available" & Pickup.point == "Airport") 
uber_data_NCA_City <- subset(uber_data, Status == "No Cars Available" & Pickup.point == "City") 

####################################################################################################################
# Cancelled                                                                                                        #
####################################################################################################################

#Day wise plotting for "Cancelled" requests for Airport

#for day 11th july
uber_CAair_11      <- subset(uber_data_CA_Air, Request_day == "11")
uber_CAair11_group <- group_by(uber_CAair_11, RQ_timeslots)
uber_CAair11_sum   <- summarise(uber_CAair11_group, length(RQ_timeslots))

P_11 <- ggplot(uber_data_CA_Air, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("11th July") 

#for day 12th july
uber_CAair_12      <- subset(uber_data_CA_Air, Request_day == "12")
uber_CAair12_group <- group_by(uber_CAair_12, RQ_timeslots)
uber_CAair12_sum   <- summarise(uber_CAair12_group, length(RQ_timeslots))

P_12 <- ggplot(uber_CAair_12, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("12th July")

#for day 13th july
uber_CAair_13      <- subset(uber_data_CA_Air, Request_day == "13")
uber_CAair13_group <- group_by(uber_CAair_13, RQ_timeslots)
uber_CAair13_sum   <- summarise(uber_CAair13_group, length(RQ_timeslots))

P_13 <- ggplot(uber_CAair_13, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("13th July")

#for day 14th july
uber_CAair_14      <- subset(uber_data_CA_Air, Request_day == "14")
uber_CAair14_group <- group_by(uber_CAair_14, RQ_timeslots)
uber_CAair14_sum   <- summarise(uber_CAair14_group, length(RQ_timeslots))

P_14 <- ggplot(uber_CAair_14, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("14th July")

#for day 15th july
uber_CAair_15      <- subset(uber_data_CA_Air, Request_day == "15")
uber_CAair15_group <- group_by(uber_CAair_15, RQ_timeslots)
uber_CAair15_sum   <- summarise(uber_CAair15_group, length(RQ_timeslots))

P_15 <- ggplot(uber_CAair_15, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("15th July")  

#Plotting graphs of each day in a single page for understanding the data

grid.arrange(P_11, P_12, P_13, P_14, P_15, ncol = 2, top = "Day wise plot for Airport cancellation plot") 

######################################################################################################################
#irrespective of day considering the hours plot for pickup point as Airport                                          #
######################################################################################################################

uber_CAair_group <- group_by(uber_data_CA_Air, RQ_timeslots)
uber_CAair_sum   <- summarise(uber_CAair_group, RQ_timeslot_count = length(RQ_timeslots))

P_Air <- ggplot(uber_data_CA_Air, aes(RQ_timeslots)) + geom_histogram(stat = "count") +  
         ggtitle("Airport-Cancellation plot")

#Day wise plotting for "Cancelled" requests for City

#for day 11th july
uber_CACity_11      <- subset(uber_data_CA_City, Request_day == "11")
uber_CACity11_group <- group_by(uber_CACity_11, RQ_timeslots)
uber_CACity11_sum   <- summarise(uber_CACity11_group, length(RQ_timeslots))

PC_11 <- ggplot( uber_CACity_11, aes(RQ_timeslots)) +  geom_histogram(stat = "count")  + ggtitle("11th July")

#for day 12th july
uber_CACity_12      <- subset(uber_data_CA_City, Request_day == "12")
uber_CACity12_group <- group_by(uber_CACity_12, RQ_timeslots)
uber_CACity12_sum   <- summarise(uber_CACity12_group, length(RQ_timeslots))

PC_12 <- ggplot(uber_CACity_12, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("12th July")

#for day 13th july
uber_CACity_13      <- subset(uber_data_CA_City, Request_day == "13")
uber_CACity13_group <- group_by(uber_CACity_13, RQ_timeslots)
uber_CACity13_sum   <- summarise(uber_CACity13_group, length(RQ_timeslots))

PC_13 <- ggplot(uber_CACity_13, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("13th July")

#for day 14th july
uber_CACity_14      <- subset(uber_data_CA_City, Request_day == "14")
uber_CACity14_group <- group_by(uber_CACity_14, RQ_timeslots)
uber_CACity14_sum   <- summarise(uber_CACity14_group, length(RQ_timeslots))

PC_14 <- ggplot(uber_CACity_14, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("14th July")

#for day 15th july
uber_CACity_15      <- subset(uber_data_CA_City, Request_day == "15")
uber_CACity15_group <- group_by(uber_CACity_15, RQ_timeslots)
uber_CACity15_sum   <- summarise(uber_CACity15_group, length(RQ_timeslots))

PC_15 <- ggplot(uber_CACity_15, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("15th July")

#Plotting graphs of each day in a single page for understanding the data

grid.arrange(PC_11, PC_12, PC_13, PC_14, PC_15, ncol = 2, top = "Day wise plot for City cancellation plot")

######################################################################################################################
#irrespective of day considering the hours plot for pickup point as City                                             #
######################################################################################################################
uber_CAcity_group <- group_by(uber_data_CA_City, RQ_timeslots)
uber_CAcity_sum   <- summarise(uber_CAcity_group, RQ_timeslot_count = length(RQ_timeslots))

P_City <- ggplot(uber_data_CA_City, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
          ggtitle("City-Cancellation plot")

######################################################################################################################
#Plotting graphs of pickup points at Airport & city to understand the cancellation summary                           #
######################################################################################################################
grid.arrange(P_Air, P_City, ncol = 2, top = "Cancellation summary plot")

######################################################################################################################
# No cars available                                                                                                  #
######################################################################################################################

#Day wise plotting for "No Cars Available" requests for Airport

#for day 11th july
uber_NCAair_11      <- subset(uber_data_NCA_Air, Request_day == "11")
uber_NCAair11_group <- group_by(uber_NCAair_11, RQ_timeslots)
uber_NCAair11_sum   <- summarise(uber_NCAair11_group, length(RQ_timeslots))

PN_11 <- ggplot(uber_NCAair_11, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("11th July")

#for day 12th july
uber_NCAair_12      <- subset(uber_data_NCA_Air, Request_day == "12")
uber_NCAair12_group <- group_by(uber_NCAair_12, RQ_timeslots)
uber_NCAair12_sum   <- summarise(uber_NCAair12_group, length(RQ_timeslots))

PN_12 <- ggplot(uber_NCAair_12, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("12th July")

#for day 13th july
uber_NCAair_13      <- subset(uber_data_NCA_Air, Request_day == "13")
uber_NCAair13_group <- group_by(uber_NCAair_13, RQ_timeslots)
uber_NCAair13_sum   <- summarise(uber_NCAair13_group, length(RQ_timeslots))

PN_13 <- ggplot(uber_NCAair_13, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("13th July")

#for day 14th july
uber_NCAair_14      <- subset(uber_data_NCA_Air, Request_day == "14")
uber_NCAair14_group <- group_by(uber_NCAair_14, RQ_timeslots)
uber_NCAair14_sum   <- summarise(uber_NCAair14_group, length(RQ_timeslots))

PN_14 <- ggplot(uber_NCAair_14, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("14th July")

#for day 15th july
uber_NCAair_15      <- subset(uber_data_NCA_Air, Request_day == "15")
uber_NCAair15_group <- group_by(uber_NCAair_15, RQ_timeslots)
uber_NCAair15_sum   <- summarise(uber_NCAair15_group, length(RQ_timeslots))

PN_15 <- ggplot(uber_NCAair_15, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("15th July")

#Plotting graphs of each day in a single page for understanding the data

grid.arrange(PN_11, PN_12, PN_13, PN_14, PN_15, ncol = 2, top = "Day wise plot for Airport-No cars available plot") 

######################################################################################################################
#irrespective of day considering the hours plot for pickup point as Airport                                          #
######################################################################################################################
uber_NCAair_group <- group_by(uber_data_NCA_Air, RQ_timeslots)
uber_NCAair_sum   <- summarise(uber_NCAair_group, RQ_timeslot_count = length(RQ_timeslots))

PNCA_Air <- ggplot(uber_data_NCA_Air, aes(RQ_timeslots)) + geom_histogram(stat = "count") +  
            ggtitle("Airport-No cars available plot")

#Day wise plotting for "No Cars Available" requests for City
#for day 11th july
uber_NCA_City_11      <- subset(uber_data_NCA_City, Request_day == "11")
uber_NCA_City11_group <- group_by(uber_NCA_City_11, RQ_timeslots)
uber_NCA_City11_sum   <- summarise(uber_NCA_City11_group, length(RQ_timeslots))

PNC_11 <- ggplot(uber_NCA_City_11, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("11th July")

#for day 12th july
uber_NCA_City_12      <- subset(uber_data_NCA_City, Request_day == "12")
uber_NCA_City12_group <- group_by(uber_NCA_City_12, RQ_timeslots)
uber_NCA_City12_sum   <- summarise(uber_NCA_City12_group, length(RQ_timeslots))

PNC_12 <- ggplot(uber_NCA_City_12, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("12th July")

#for day 13th july
uber_NCA_City_13      <- subset(uber_data_NCA_City, Request_day == "13")
uber_NCA_City13_group <- group_by(uber_NCA_City_13, RQ_timeslots)
uber_NCA_City13_sum   <- summarise(uber_NCA_City13_group, length(RQ_timeslots))

PNC_13 <- ggplot(uber_NCA_City_13, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("13th July")

#for day 14th july
uber_NCA_City_14      <- subset(uber_data_NCA_City, Request_day == "14")
uber_NCA_City14_group <- group_by(uber_NCA_City_14, RQ_timeslots)
uber_NCA_City14_sum   <- summarise(uber_NCA_City14_group, length(RQ_timeslots))

PNC_14 <- ggplot(uber_NCA_City_14, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("14th July")

#for day 15th july
uber_NCA_City_15      <- subset(uber_data_NCA_City, Request_day == "15")
uber_NCA_City15_group <- group_by(uber_NCA_City_15, RQ_timeslots)
uber_NCA_City15_sum   <- summarise(uber_NCA_City15_group, length(RQ_timeslots))

PNC_15 <- ggplot(uber_NCA_City_15, aes(RQ_timeslots)) + geom_histogram(stat = "count") + ggtitle("15th July")
#Plotting graphs of each day in a single page for understanding the data

grid.arrange(PNC_11, PNC_12, PNC_13, PNC_14, PNC_15, ncol = 2, top = "Day wise plot for City-No cars available plot")

######################################################################################################################
#irrespective of day considering the hours plot for pickup point as City                                             #
######################################################################################################################
uber_NCAcity_group <- group_by(uber_data_NCA_City, RQ_timeslots)
uber_NCAcity_sum   <- summarise(uber_NCAcity_group, RQ_timeslot_count = length(RQ_timeslots))

PNCA_City <- ggplot(uber_data_NCA_City, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
             ggtitle("City-No cars available plot")

######################################################################################################################
#Plotting graphs of pickup points at Airport & city to understand the "cancellation"No Cars Available" summary       #
######################################################################################################################
grid.arrange(PNCA_Air, PNCA_City, ncol = 2, top = "No cars available summary plot")

#####################################################################################################################
# Demand & Supply gap calculation and plotting                                                                      #
#####################################################################################################################

Uber_data_total_supply <- subset(uber_data, Status == "Trip Completed")
Uber_data_total_demand <- uber_data 

Uber_data_total_supply_grp <- group_by(Uber_data_total_supply, RQ_timeslots)
Uber_data_total_supply_sum <- summarise(Uber_data_total_supply_grp, RQ_timeslot_count = length(RQ_timeslots))

Uber_data_total_demand_grp <- group_by(Uber_data_total_demand, RQ_timeslots)
Uber_data_total_demand_sum <- summarise(Uber_data_total_demand_grp, RQ_timeslot_count = length(RQ_timeslots))

# Retreiving total supply from summary and assigning to dataset field

Uber_data_total_supply$Total_supply[Uber_data_total_supply$RQ_timeslots == "Early morning"] <- 
  Uber_data_total_supply_sum$RQ_timeslot_count[Uber_data_total_supply_sum$RQ_timeslots == "Early morning"]

Uber_data_total_supply$Total_supply[Uber_data_total_supply$RQ_timeslots == "Morning"] <- 
  Uber_data_total_supply_sum$RQ_timeslot_count[Uber_data_total_supply_sum$RQ_timeslots == "Morning"]

Uber_data_total_supply$Total_supply[Uber_data_total_supply$RQ_timeslots == "Noon"] <- 
  Uber_data_total_supply_sum$RQ_timeslot_count[Uber_data_total_supply_sum$RQ_timeslots == "Noon"]

Uber_data_total_supply$Total_supply[Uber_data_total_supply$RQ_timeslots == "Evening"] <- 
  Uber_data_total_supply_sum$RQ_timeslot_count[Uber_data_total_supply_sum$RQ_timeslots == "Evening"]

Uber_data_total_supply$Total_supply[Uber_data_total_supply$RQ_timeslots == "Late evening"] <- 
  Uber_data_total_supply_sum$RQ_timeslot_count[Uber_data_total_supply_sum$RQ_timeslots == "Late evening"]

# Retreiving total demand from summary and assigning to dataset field

Uber_data_total_supply$Total_demand[Uber_data_total_supply$RQ_timeslots == "Early morning"] <-
  Uber_data_total_demand_sum$RQ_timeslot_count[Uber_data_total_demand_sum$RQ_timeslots == "Early morning"]

Uber_data_total_supply$Total_demand[Uber_data_total_supply$RQ_timeslots == "Morning"] <-
  Uber_data_total_demand_sum$RQ_timeslot_count[Uber_data_total_demand_sum$RQ_timeslots == "Morning"]

Uber_data_total_supply$Total_demand[Uber_data_total_supply$RQ_timeslots == "Noon"] <-
  Uber_data_total_demand_sum$RQ_timeslot_count[Uber_data_total_demand_sum$RQ_timeslots == "Noon"]

Uber_data_total_supply$Total_demand[Uber_data_total_supply$RQ_timeslots == "Evening"] <-
  Uber_data_total_demand_sum$RQ_timeslot_count[Uber_data_total_demand_sum$RQ_timeslots == "Evening"]

Uber_data_total_supply$Total_demand[Uber_data_total_supply$RQ_timeslots == "Late evening"] <-
  Uber_data_total_demand_sum$RQ_timeslot_count[Uber_data_total_demand_sum$RQ_timeslots == "Late evening"]

#Calculating the gap between demand and supply available as per the data for city

Uber_data_total_supply$Total_gap <- (Uber_data_total_supply$Total_demand - Uber_data_total_supply$Total_supply)

Uber_data_total_supply_group <- group_by(Uber_data_total_supply, RQ_timeslots, Total_gap)
uber_total_gap <- summarise(Uber_data_total_supply_group, Total_Gap = unique(Total_gap))

#Plotting gap between demand and supply 

text_name_total <- c(uber_total_gap$Total_Gap)
Pgap_Total <- ggplot(na.omit(uber_total_gap), aes(RQ_timeslots, Total_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_total_gap, aes(RQ_timeslots, Total_Gap, label = text_name_total),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap")

####################################################################################################################
#Plotting Supply & demand in City and Airport                                                                      #
####################################################################################################################

#Subsetting data to calculate supply at Airport & city from trip completed status 
uber_data_City_supply   <- subset(uber_data, Status == "Trip Completed" & Pickup.point == "City")
uber_data_Air_supply    <- subset(uber_data, Status == "Trip Completed" & Pickup.point == "Airport")


#For day wise plotting of City

#for 11th july
Uber_city_supply_11      <- subset(uber_data_City_supply, Request_day == "11")
Uber_city_supply11_group <- group_by(Uber_city_supply_11, RQ_timeslots)
Uber_city_supply11_sum   <- summarise(Uber_city_supply11_group, RQ_timeslot_count =length(RQ_timeslots))
P_City_supply11          <- ggplot(Uber_city_supply_11, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("11th July Supply")
#for 12th july
Uber_city_supply_12      <- subset(uber_data_City_supply, Request_day == "12")
Uber_city_supply12_group <- group_by(Uber_city_supply_12, RQ_timeslots)
Uber_city_supply12_sum   <- summarise(Uber_city_supply12_group, RQ_timeslot_count = length(RQ_timeslots))
P_City_supply12          <- ggplot(Uber_city_supply_12, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("12th July Supply")
#for 13th july
Uber_city_supply_13      <- subset(uber_data_City_supply, Request_day == "13")
Uber_city_supply13_group <- group_by(Uber_city_supply_13, RQ_timeslots)
Uber_city_supply13_sum   <- summarise(Uber_city_supply13_group, RQ_timeslot_count = length(RQ_timeslots))
P_City_supply13          <- ggplot(Uber_city_supply_13, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("13th July Supply")
#for 14th july
Uber_city_supply_14      <- subset(uber_data_City_supply, Request_day == "14")
Uber_city_supply14_group <- group_by(Uber_city_supply_14, RQ_timeslots)
Uber_city_supply14_sum   <- summarise(Uber_city_supply14_group, RQ_timeslot_count = length(RQ_timeslots))
P_City_supply14          <- ggplot(Uber_city_supply_14, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("14th July Supply")
#for 15th july
Uber_city_supply_15      <- subset(uber_data_City_supply, Request_day == "15")
Uber_city_supply15_group <- group_by(Uber_city_supply_15, RQ_timeslots)
Uber_city_supply15_sum   <- summarise(Uber_city_supply15_group, RQ_timeslot_count = length(RQ_timeslots))
P_City_supply15          <- ggplot(Uber_city_supply_15, aes(RQ_timeslots)) + geom_histogram(stat = "count") +  
  ggtitle("15th July Supply")

grid.arrange(P_City_supply11, P_City_supply12, P_City_supply13, P_City_supply14,P_City_supply15, ncol = 2, top = "Day wise plot for City-supply")

######################################################################################################################
#irrespective of day considering the hours plot for Supply in City                                                   #
######################################################################################################################
Uber_city_supply_group   <- group_by(uber_data_City_supply, RQ_timeslots)
uber_city_supply_sum     <- summarise(Uber_city_supply_group, RQ_timeslot_count =length(RQ_timeslots))

P_City_supply            <- ggplot(uber_data_City_supply, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle(" City Supply plot")

#For day wise plotting of Airport

#for 11th july
Uber_Air_supply_11      <- subset(uber_data_Air_supply, Request_day == "11")
Uber_Air_supply11_group <- group_by(Uber_Air_supply_11, RQ_timeslots)
Uber_Air_supply11_sum   <- summarise(Uber_Air_supply11_group, RQ_timeslot_count = length(RQ_timeslots))
P_Air_supply11          <- ggplot(Uber_Air_supply_11, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("11th July Supply")

#for 12th july
Uber_Air_supply_12      <- subset(uber_data_Air_supply, Request_day == "12")
Uber_Air_supply12_group <- group_by(Uber_Air_supply_12, RQ_timeslots)
Uber_Air_supply12_sum   <- summarise(Uber_Air_supply12_group, RQ_timeslot_count = length(RQ_timeslots))
P_Air_supply12          <- ggplot(Uber_Air_supply_12, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("12th July Supply")

#for 13th july
Uber_Air_supply_13      <- subset(uber_data_Air_supply, Request_day == "13")
Uber_Air_supply13_group <- group_by(Uber_Air_supply_13, RQ_timeslots)
Uber_Air_supply13_sum   <- summarise(Uber_Air_supply13_group, RQ_timeslot_count = length(RQ_timeslots))
P_Air_supply13          <- ggplot(Uber_Air_supply_13, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("13th July Supply")

#for 14th july
Uber_Air_supply_14      <- subset(uber_data_Air_supply, Request_day == "14")
Uber_Air_supply14_group <- group_by(Uber_Air_supply_14, RQ_timeslots)
Uber_Air_supply14_sum   <- summarise(Uber_Air_supply14_group, RQ_timeslot_count = length(RQ_timeslots))
P_Air_supply14          <- ggplot(Uber_Air_supply_14, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("14th July Supply")

#for 15th july
Uber_Air_supply_15      <- subset(uber_data_Air_supply, Request_day == "15")
Uber_Air_supply15_group <- group_by(Uber_Air_supply_15, RQ_timeslots)
Uber_Air_supply15_sum   <- summarise(Uber_Air_supply15_group, RQ_timeslot_count = length(RQ_timeslots))
P_Air_supply15          <- ggplot(Uber_Air_supply_15, aes(RQ_timeslots)) + geom_histogram(stat = "count") +  
  ggtitle("15th July Supply")

grid.arrange(P_Air_supply11, P_Air_supply12, P_Air_supply13, P_Air_supply14,P_Air_supply15, ncol = 2, top = "Day wise plot for Airport-supply")

######################################################################################################################
#irrespective of day considering the hours plot for Supply in Airport                                                #
######################################################################################################################
Uber_Air_supply_group    <- group_by(uber_data_Air_supply, RQ_timeslots)
Uber_Air_supply_sum      <- summarise(Uber_Air_supply_group, RQ_timeslot_count = length(RQ_timeslots))

P_Air_supply             <- ggplot(uber_data_Air_supply, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("Airport supply plot")

######################################################################################################################
#Understanding summary of supply                                                                                     #
######################################################################################################################
grid.arrange(P_City_supply, P_Air_supply, ncol = 2, top = "Supply summary plot")

#Plotting for demand
uber_data_City_Demand    <- subset(uber_data, Pickup.point == "City") 
uber_data_Air_Demand    <- subset(uber_data, Pickup.point == "Airport")


#For day wise plotting of city

#for 11th july
Uber_city_Demand_11      <- subset(uber_data_City_Demand , Request_day == "11")
Uber_city_Demand11_group <- group_by(Uber_city_Demand_11, RQ_timeslots)
Uber_city_Demand11_sum   <- summarise(Uber_city_Demand11_group, RQ_timeslot_count = length(RQ_timeslots))
P_City_Demand11          <- ggplot(Uber_city_Demand_11, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("11th July Demand")
#for 12th july
Uber_city_Demand_12      <- subset(uber_data_City_Demand , Request_day == "12")
Uber_city_Demand12_group <- group_by(Uber_city_Demand_12, RQ_timeslots)
Uber_city_Demand12_sum   <- summarise(Uber_city_Demand12_group, RQ_timeslot_count = length(RQ_timeslots))
P_City_Demand12          <- ggplot(Uber_city_Demand_12, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("12th July Demand")
#for 13th july
Uber_city_Demand_13      <- subset(uber_data_City_Demand , Request_day == "13")
Uber_city_Demand13_group <- group_by(Uber_city_Demand_13, RQ_timeslots)
Uber_city_Demand13_sum   <- summarise(Uber_city_Demand13_group, RQ_timeslot_count = length(RQ_timeslots))
P_City_Demand13          <- ggplot(Uber_city_Demand_13, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("13th July Demand")
#for 14th july
Uber_city_Demand_14      <- subset(uber_data_City_Demand , Request_day == "14")
Uber_city_Demand14_group <- group_by(Uber_city_Demand_14, RQ_timeslots)
Uber_city_Demand14_sum   <- summarise(Uber_city_Demand14_group, RQ_timeslot_count = length(RQ_timeslots))
P_City_Demand14          <- ggplot(Uber_city_Demand_14, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("14th July Demand")
#for 15th july
Uber_city_Demand_15      <- subset(uber_data_City_Demand , Request_day == "15")
Uber_city_Demand15_group <- group_by(Uber_city_Demand_15, RQ_timeslots)
Uber_city_Demand15_sum   <- summarise(Uber_city_Demand15_group, RQ_timeslot_count = length(RQ_timeslots))
P_City_Demand15          <- ggplot(Uber_city_Demand_15, aes(RQ_timeslots)) + geom_histogram(stat = "count") +  
  ggtitle("15th July Demand")

grid.arrange(P_City_Demand11, P_City_Demand12, P_City_Demand13, P_City_Demand14,P_City_Demand15, ncol = 2, top = "Day wise plot for City-Demand")

######################################################################################################################
#irrespective of day considering the hours plot for Demand in City                                                   #
######################################################################################################################
Uber_city_Demand_group   <- group_by(uber_data_City_Demand , RQ_timeslots)
Uber_city_Demand_sum     <- summarise(Uber_city_Demand_group, RQ_timeslot_count = length(RQ_timeslots))

P_City_Demand              <- ggplot(uber_data_City_Demand , aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle(" City Demand plot")

#For day wise plotting of Airport

#for 11th july
Uber_Air_Demand_11      <- subset(uber_data_Air_Demand, Request_day == "11")
Uber_Air_Demand11_group <- group_by(Uber_Air_Demand_11, RQ_timeslots)
Uber_Air_Demand11_sum   <- summarise(Uber_Air_Demand11_group, RQ_timeslot_count = length(RQ_timeslots))
P_Air_Demand11          <- ggplot(Uber_Air_Demand_11, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("11th July Demand")

#for 12th july
Uber_Air_Demand_12      <- subset(uber_data_Air_Demand, Request_day == "12")
Uber_Air_Demand12_group <- group_by(Uber_Air_Demand_12, RQ_timeslots)
Uber_Air_Demand12_sum   <- summarise(Uber_Air_Demand12_group, RQ_timeslot_count = length(RQ_timeslots))
P_Air_Demand12          <- ggplot(Uber_Air_Demand_12, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("12th July Demand")

#for 13th july
Uber_Air_Demand_13      <- subset(uber_data_Air_Demand, Request_day == "13")
Uber_Air_Demand13_group <- group_by(Uber_Air_Demand_13, RQ_timeslots)
Uber_Air_Demand13_sum   <- summarise(Uber_Air_Demand13_group, RQ_timeslot_count = length(RQ_timeslots))
P_Air_Demand13          <- ggplot(Uber_Air_Demand_13, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("13th July Demand")

#for 14th july
Uber_Air_Demand_14      <- subset(uber_data_Air_Demand, Request_day == "14")
Uber_Air_Demand14_group <- group_by(Uber_Air_Demand_14, RQ_timeslots)
Uber_Air_Demand14_sum   <- summarise(Uber_Air_Demand14_group, RQ_timeslot_count = length(RQ_timeslots))
P_Air_Demand14          <- ggplot(Uber_Air_Demand_14, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("14th July Demand")

#for 15th july
Uber_Air_Demand_15      <- subset(uber_data_Air_Demand, Request_day == "15")
Uber_Air_Demand15_group <- group_by(Uber_Air_Demand_15, RQ_timeslots)
Uber_Air_Demand15_sum   <- summarise(Uber_Air_Demand15_group, RQ_timeslot_count = length(RQ_timeslots))
P_Air_Demand15          <- ggplot(Uber_Air_Demand_15, aes(RQ_timeslots)) + geom_histogram(stat = "count") +  
  ggtitle("15th July Demand")

grid.arrange(P_Air_Demand11, P_Air_Demand12, P_Air_Demand13, P_Air_Demand14,P_Air_Demand15, ncol = 2, top = "Day wise plot for Airport-Demand")

######################################################################################################################
#irrespective of day considering the hours plot for Demand in Airport                                                #
######################################################################################################################
Uber_Air_Demand_group    <- group_by(uber_data_Air_Demand, RQ_timeslots)
Uber_Air_Demand_sum      <- summarise(Uber_Air_Demand_group, RQ_timeslot_count = length(RQ_timeslots))

P_Air_Demand               <- ggplot(uber_data_Air_Demand, aes(RQ_timeslots)) + geom_histogram(stat = "count") +
  ggtitle("Airport Demand plot")

######################################################################################################################
# DEMAND VS SUPPLY Summary for Airport and City                                                                      #
######################################################################################################################

grid.arrange(P_Air_Demand, P_Air_supply, ncol=2, top="Demand Vs Supply - Airport")
grid.arrange(P_City_Demand, P_City_supply, ncol=2, top="Demand Vs Supply - City")

######################################################################################################################
# Calculating the gap between demand and supply                                                                      #
######################################################################################################################

# Retreiving total supply for city from summary and assigning to dataset field

uber_data_City_supply$CityTotal_supply[uber_data_City_supply$RQ_timeslots == "Early morning"] <- 
  uber_city_supply_sum$RQ_timeslot_count[uber_city_supply_sum$RQ_timeslots == "Early morning"]

uber_data_City_supply$CityTotal_supply[uber_data_City_supply$RQ_timeslots == "Morning"] <- 
  uber_city_supply_sum$RQ_timeslot_count[uber_city_supply_sum$RQ_timeslots == "Morning"]

uber_data_City_supply$CityTotal_supply[uber_data_City_supply$RQ_timeslots == "Noon"] <- 
  uber_city_supply_sum$RQ_timeslot_count[uber_city_supply_sum$RQ_timeslots == "Noon"]

uber_data_City_supply$CityTotal_supply[uber_data_City_supply$RQ_timeslots == "Evening"] <- 
  uber_city_supply_sum$RQ_timeslot_count[uber_city_supply_sum$RQ_timeslots == "Evening"]

uber_data_City_supply$CityTotal_supply[uber_data_City_supply$RQ_timeslots == "Late evening"] <- 
  uber_city_supply_sum$RQ_timeslot_count[uber_city_supply_sum$RQ_timeslots == "Late evening"]

# Retreiving total supply for Airport from summary and assigning to dataset field

uber_data_Air_supply$AirTotal_supply[uber_data_Air_supply$RQ_timeslots == "Early morning"] <- 
  Uber_Air_supply_sum$RQ_timeslot_count[Uber_Air_supply_sum$RQ_timeslots == "Early morning"]

uber_data_Air_supply$AirTotal_supply[uber_data_Air_supply$RQ_timeslots == "Morning"] <- 
  Uber_Air_supply_sum$RQ_timeslot_count[Uber_Air_supply_sum$RQ_timeslots == "Morning"]

uber_data_Air_supply$AirTotal_supply[uber_data_Air_supply$RQ_timeslots == "Noon"] <- 
  Uber_Air_supply_sum$RQ_timeslot_count[Uber_Air_supply_sum$RQ_timeslots == "Noon"]

uber_data_Air_supply$AirTotal_supply[uber_data_Air_supply$RQ_timeslots == "Evening"] <- 
  Uber_Air_supply_sum$RQ_timeslot_count[Uber_Air_supply_sum$RQ_timeslots == "Evening"]

uber_data_Air_supply$AirTotal_supply[uber_data_Air_supply$RQ_timeslots == "Late evening"] <- 
  Uber_Air_supply_sum$RQ_timeslot_count[Uber_Air_supply_sum$RQ_timeslots == "Late evening"]

# Retreiving total demand for city from summary and assigning to dataset field

uber_data_City_supply$CityTotal_demand[uber_data_City_supply$RQ_timeslots == "Early morning"] <-
  Uber_city_Demand_sum$RQ_timeslot_count[Uber_city_Demand_sum$RQ_timeslots == "Early morning"]

uber_data_City_supply$CityTotal_demand[uber_data_City_supply$RQ_timeslots == "Morning"] <-
  Uber_city_Demand_sum$RQ_timeslot_count[Uber_city_Demand_sum$RQ_timeslots == "Morning"]

uber_data_City_supply$CityTotal_demand[uber_data_City_supply$RQ_timeslots == "Noon"] <-
  Uber_city_Demand_sum$RQ_timeslot_count[Uber_city_Demand_sum$RQ_timeslots == "Noon"]

uber_data_City_supply$CityTotal_demand[uber_data_City_supply$RQ_timeslots == "Evening"] <-
  Uber_city_Demand_sum$RQ_timeslot_count[Uber_city_Demand_sum$RQ_timeslots == "Evening"]

uber_data_City_supply$CityTotal_demand[uber_data_City_supply$RQ_timeslots == "Late evening"] <-
  Uber_city_Demand_sum$RQ_timeslot_count[Uber_city_Demand_sum$RQ_timeslots == "Late evening"]

#Calculating the gap between demand and supply available as per the data for city

uber_data_City_supply$City_gap <- (uber_data_City_supply$CityTotal_demand - uber_data_City_supply$CityTotal_supply)

uber_data_City_supply_group <- group_by(uber_data_City_supply, RQ_timeslots, City_gap)
uber_city_gap <- summarise(uber_data_City_supply_group, City_Gap = unique(City_gap))

#Plotting gap between demand and supply available as per data for city

text_name_city <- c(uber_city_gap$City_Gap)
Pgap_City <- ggplot(na.omit(uber_city_gap), aes(RQ_timeslots, City_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_city_gap, aes(RQ_timeslots, City_Gap, label = text_name_city),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap for pickup point at City")

# Retreiving total demand for Aiport from summary and assigning to dataset field

uber_data_Air_supply$AirTotal_demand[uber_data_Air_supply$RQ_timeslots == "Early morning"] <-
  Uber_Air_Demand_sum$RQ_timeslot_count[Uber_Air_Demand_sum$RQ_timeslots == "Early morning"]

uber_data_Air_supply$AirTotal_demand[uber_data_Air_supply$RQ_timeslots == "Morning"] <-
  Uber_Air_Demand_sum$RQ_timeslot_count[Uber_Air_Demand_sum$RQ_timeslots == "Morning"]

uber_data_Air_supply$AirTotal_demand[uber_data_Air_supply$RQ_timeslots == "Noon"] <-
  Uber_Air_Demand_sum$RQ_timeslot_count[Uber_Air_Demand_sum$RQ_timeslots == "Noon"]

uber_data_Air_supply$AirTotal_demand[uber_data_Air_supply$RQ_timeslots == "Evening"] <-
  Uber_Air_Demand_sum$RQ_timeslot_count[Uber_Air_Demand_sum$RQ_timeslots == "Evening"]

uber_data_Air_supply$AirTotal_demand[uber_data_Air_supply$RQ_timeslots == "Late evening"] <-
  Uber_Air_Demand_sum$RQ_timeslot_count[Uber_Air_Demand_sum$RQ_timeslots == "Late evening"]

#Calculating the gap between demand and supply available as per the data for Airport

uber_data_Air_supply$Air_gap <- (uber_data_Air_supply$AirTotal_demand - uber_data_Air_supply$AirTotal_supply)

uber_data_Air_supply_group <- group_by(uber_data_Air_supply, RQ_timeslots, Air_gap)
uber_Air_gap <- summarise(uber_data_Air_supply_group, Air_Gap = unique(Air_gap))

#Plotting gap between demand and supply available as per data for Airport
text_name_Air <- c(uber_Air_gap$Air_Gap)
Pgap_Air  <- ggplot(na.omit(uber_Air_gap), aes(RQ_timeslots, Air_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_Air_gap, aes(RQ_timeslots, Air_Gap, label = text_name_Air),size=4, hjust = 1.3, vjust = 1.3) +
  ggtitle("Demand - Supply gap for pickup point at Airport")

######################################################################################################################
# GAP Summary for Airport and City                                                                                   #
######################################################################################################################
grid.arrange(Pgap_Air, Pgap_City, ncol=2, top="Summary Gap plot for - Airport & City")

#Day wise gap 11
Uber_city_supply_11$CityTotal_supply[Uber_city_supply_11$RQ_timeslots == "Early morning"] <- 
  Uber_city_supply11_sum$RQ_timeslot_count[Uber_city_supply11_sum$RQ_timeslots == "Early morning"]

Uber_city_supply_11$CityTotal_supply[Uber_city_supply_11$RQ_timeslots == "Morning"] <- 
  Uber_city_supply11_sum$RQ_timeslot_count[Uber_city_supply11_sum$RQ_timeslots == "Morning"]

Uber_city_supply_11$CityTotal_supply[Uber_city_supply_11$RQ_timeslots == "Noon"] <- 
  Uber_city_supply11_sum$RQ_timeslot_count[Uber_city_supply11_sum$RQ_timeslots == "Noon"]

Uber_city_supply_11$CityTotal_supply[Uber_city_supply_11$RQ_timeslots == "Evening"] <- 
  Uber_city_supply11_sum$RQ_timeslot_count[Uber_city_supply11_sum$RQ_timeslots == "Evening"]

Uber_city_supply_11$CityTotal_supply[Uber_city_supply_11$RQ_timeslots == "Late evening"] <- 
  Uber_city_supply11_sum$RQ_timeslot_count[Uber_city_supply11_sum$RQ_timeslots == "Late evening"]


Uber_city_supply_11$CityTotal_demand[Uber_city_supply_11$RQ_timeslots == "Early morning"] <- 
  Uber_city_Demand11_sum$RQ_timeslot_count[Uber_city_Demand11_sum$RQ_timeslots == "Early morning"]

Uber_city_supply_11$CityTotal_demand[Uber_city_supply_11$RQ_timeslots == "Morning"] <- 
  Uber_city_Demand11_sum$RQ_timeslot_count[Uber_city_Demand11_sum$RQ_timeslots == "Morning"]

Uber_city_supply_11$CityTotal_demand[Uber_city_supply_11$RQ_timeslots == "Noon"] <- 
  Uber_city_Demand11_sum$RQ_timeslot_count[Uber_city_Demand11_sum$RQ_timeslots == "Noon"]

Uber_city_supply_11$CityTotal_demand[Uber_city_supply_11$RQ_timeslots == "Evening"] <- 
  Uber_city_Demand11_sum$RQ_timeslot_count[Uber_city_Demand11_sum$RQ_timeslots == "Evening"]

Uber_city_supply_11$CityTotal_demand[Uber_city_supply_11$RQ_timeslots == "Late evening"] <- 
  Uber_city_Demand11_sum$RQ_timeslot_count[Uber_city_Demand11_sum$RQ_timeslots == "Late evening"]


#Calculating the gap between demand and supply available as per the data for city

Uber_city_supply_11$City_gap <- (Uber_city_supply_11$CityTotal_demand - Uber_city_supply_11$CityTotal_supply)

Uber_city_supply_11_group <- group_by(Uber_city_supply_11, RQ_timeslots, City_gap)
uber_city_gap11 <- summarise(Uber_city_supply_11_group, City_Gap = unique(City_gap))

#Plotting gap between demand and supply available as per data for city

text_name_city11 <- c(uber_city_gap11$City_Gap)
Pgap_City11 <- ggplot(na.omit(uber_city_gap11), aes(RQ_timeslots, City_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_city_gap11, aes(RQ_timeslots, City_Gap, label = text_name_city11),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap at City on 11th july")

#Day wise gap 12
Uber_city_supply_12$CityTotal_supply[Uber_city_supply_12$RQ_timeslots == "Early morning"] <- 
  Uber_city_supply12_sum$RQ_timeslot_count[Uber_city_supply12_sum$RQ_timeslots == "Early morning"]

Uber_city_supply_12$CityTotal_supply[Uber_city_supply_12$RQ_timeslots == "Morning"] <- 
  Uber_city_supply12_sum$RQ_timeslot_count[Uber_city_supply12_sum$RQ_timeslots == "Morning"]

Uber_city_supply_12$CityTotal_supply[Uber_city_supply_12$RQ_timeslots == "Noon"] <- 
  Uber_city_supply12_sum$RQ_timeslot_count[Uber_city_supply12_sum$RQ_timeslots == "Noon"]

Uber_city_supply_12$CityTotal_supply[Uber_city_supply_12$RQ_timeslots == "Evening"] <- 
  Uber_city_supply12_sum$RQ_timeslot_count[Uber_city_supply12_sum$RQ_timeslots == "Evening"]

Uber_city_supply_12$CityTotal_supply[Uber_city_supply_12$RQ_timeslots == "Late evening"] <- 
  Uber_city_supply12_sum$RQ_timeslot_count[Uber_city_supply12_sum$RQ_timeslots == "Late evening"]


Uber_city_supply_12$CityTotal_demand[Uber_city_supply_12$RQ_timeslots == "Early morning"] <- 
  Uber_city_Demand12_sum$RQ_timeslot_count[Uber_city_Demand12_sum$RQ_timeslots == "Early morning"]

Uber_city_supply_12$CityTotal_demand[Uber_city_supply_12$RQ_timeslots == "Morning"] <- 
  Uber_city_Demand12_sum$RQ_timeslot_count[Uber_city_Demand12_sum$RQ_timeslots == "Morning"]

Uber_city_supply_12$CityTotal_demand[Uber_city_supply_12$RQ_timeslots == "Noon"] <- 
  Uber_city_Demand12_sum$RQ_timeslot_count[Uber_city_Demand12_sum$RQ_timeslots == "Noon"]

Uber_city_supply_12$CityTotal_demand[Uber_city_supply_12$RQ_timeslots == "Evening"] <- 
  Uber_city_Demand12_sum$RQ_timeslot_count[Uber_city_Demand12_sum$RQ_timeslots == "Evening"]

Uber_city_supply_12$CityTotal_demand[Uber_city_supply_12$RQ_timeslots == "Late evening"] <- 
  Uber_city_Demand12_sum$RQ_timeslot_count[Uber_city_Demand12_sum$RQ_timeslots == "Late evening"]


#Calculating the gap between demand and supply available as per the data for city

Uber_city_supply_12$City_gap <- (Uber_city_supply_12$CityTotal_demand - Uber_city_supply_12$CityTotal_supply)

Uber_city_supply_12_group <- group_by(Uber_city_supply_12, RQ_timeslots, City_gap)
uber_city_gap12 <- summarise(Uber_city_supply_12_group, City_Gap = unique(City_gap))

#Plotting gap between demand and supply available as per data for city

text_name_city12 <- c(uber_city_gap12$City_Gap)
Pgap_City12 <- ggplot(na.omit(uber_city_gap12), aes(RQ_timeslots, City_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_city_gap12, aes(RQ_timeslots, City_Gap, label = text_name_city12),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap at City on 12th july")

#Day wise gap 13
Uber_city_supply_13$CityTotal_supply[Uber_city_supply_13$RQ_timeslots == "Early morning"] <- 
  Uber_city_supply13_sum$RQ_timeslot_count[Uber_city_supply13_sum$RQ_timeslots == "Early morning"]

Uber_city_supply_13$CityTotal_supply[Uber_city_supply_13$RQ_timeslots == "Morning"] <- 
  Uber_city_supply13_sum$RQ_timeslot_count[Uber_city_supply13_sum$RQ_timeslots == "Morning"]

Uber_city_supply_13$CityTotal_supply[Uber_city_supply_13$RQ_timeslots == "Noon"] <- 
  Uber_city_supply13_sum$RQ_timeslot_count[Uber_city_supply13_sum$RQ_timeslots == "Noon"]

Uber_city_supply_13$CityTotal_supply[Uber_city_supply_13$RQ_timeslots == "Evening"] <- 
  Uber_city_supply13_sum$RQ_timeslot_count[Uber_city_supply13_sum$RQ_timeslots == "Evening"]

Uber_city_supply_13$CityTotal_supply[Uber_city_supply_13$RQ_timeslots == "Late evening"] <- 
  Uber_city_supply13_sum$RQ_timeslot_count[Uber_city_supply13_sum$RQ_timeslots == "Late evening"]


Uber_city_supply_13$CityTotal_demand[Uber_city_supply_13$RQ_timeslots == "Early morning"] <- 
  Uber_city_Demand13_sum$RQ_timeslot_count[Uber_city_Demand13_sum$RQ_timeslots == "Early morning"]

Uber_city_supply_13$CityTotal_demand[Uber_city_supply_13$RQ_timeslots == "Morning"] <- 
  Uber_city_Demand13_sum$RQ_timeslot_count[Uber_city_Demand13_sum$RQ_timeslots == "Morning"]

Uber_city_supply_13$CityTotal_demand[Uber_city_supply_13$RQ_timeslots == "Noon"] <- 
  Uber_city_Demand13_sum$RQ_timeslot_count[Uber_city_Demand13_sum$RQ_timeslots == "Noon"]

Uber_city_supply_13$CityTotal_demand[Uber_city_supply_13$RQ_timeslots == "Evening"] <- 
  Uber_city_Demand13_sum$RQ_timeslot_count[Uber_city_Demand13_sum$RQ_timeslots == "Evening"]

Uber_city_supply_13$CityTotal_demand[Uber_city_supply_13$RQ_timeslots == "Late evening"] <- 
  Uber_city_Demand13_sum$RQ_timeslot_count[Uber_city_Demand13_sum$RQ_timeslots == "Late evening"]


#Calculating the gap between demand and supply available as per the data for city

Uber_city_supply_13$City_gap <- (Uber_city_supply_13$CityTotal_demand - Uber_city_supply_13$CityTotal_supply)

Uber_city_supply_13_group <- group_by(Uber_city_supply_13, RQ_timeslots, City_gap)
uber_city_gap13 <- summarise(Uber_city_supply_13_group, City_Gap = unique(City_gap))

#Plotting gap between demand and supply available as per data for city

text_name_city13 <- c(uber_city_gap13$City_Gap)
Pgap_City13 <- ggplot(na.omit(uber_city_gap13), aes(RQ_timeslots, City_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_city_gap13, aes(RQ_timeslots, City_Gap, label = text_name_city13),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap at City on 13th july")

#Day wise gap 14
Uber_city_supply_14$CityTotal_supply[Uber_city_supply_14$RQ_timeslots == "Early morning"] <- 
  Uber_city_supply14_sum$RQ_timeslot_count[Uber_city_supply14_sum$RQ_timeslots == "Early morning"]

Uber_city_supply_14$CityTotal_supply[Uber_city_supply_14$RQ_timeslots == "Morning"] <- 
  Uber_city_supply14_sum$RQ_timeslot_count[Uber_city_supply14_sum$RQ_timeslots == "Morning"]

Uber_city_supply_14$CityTotal_supply[Uber_city_supply_14$RQ_timeslots == "Noon"] <- 
  Uber_city_supply14_sum$RQ_timeslot_count[Uber_city_supply14_sum$RQ_timeslots == "Noon"]

Uber_city_supply_14$CityTotal_supply[Uber_city_supply_14$RQ_timeslots == "Evening"] <- 
  Uber_city_supply14_sum$RQ_timeslot_count[Uber_city_supply14_sum$RQ_timeslots == "Evening"]

Uber_city_supply_14$CityTotal_supply[Uber_city_supply_14$RQ_timeslots == "Late evening"] <- 
  Uber_city_supply14_sum$RQ_timeslot_count[Uber_city_supply14_sum$RQ_timeslots == "Late evening"]


Uber_city_supply_14$CityTotal_demand[Uber_city_supply_14$RQ_timeslots == "Early morning"] <- 
  Uber_city_Demand14_sum$RQ_timeslot_count[Uber_city_Demand14_sum$RQ_timeslots == "Early morning"]

Uber_city_supply_14$CityTotal_demand[Uber_city_supply_14$RQ_timeslots == "Morning"] <- 
  Uber_city_Demand14_sum$RQ_timeslot_count[Uber_city_Demand14_sum$RQ_timeslots == "Morning"]

Uber_city_supply_14$CityTotal_demand[Uber_city_supply_14$RQ_timeslots == "Noon"] <- 
  Uber_city_Demand14_sum$RQ_timeslot_count[Uber_city_Demand14_sum$RQ_timeslots == "Noon"]

Uber_city_supply_14$CityTotal_demand[Uber_city_supply_14$RQ_timeslots == "Evening"] <- 
  Uber_city_Demand14_sum$RQ_timeslot_count[Uber_city_Demand14_sum$RQ_timeslots == "Evening"]

Uber_city_supply_14$CityTotal_demand[Uber_city_supply_14$RQ_timeslots == "Late evening"] <- 
  Uber_city_Demand14_sum$RQ_timeslot_count[Uber_city_Demand14_sum$RQ_timeslots == "Late evening"]


#Calculating the gap between demand and supply available as per the data for city

Uber_city_supply_14$City_gap <- (Uber_city_supply_14$CityTotal_demand - Uber_city_supply_14$CityTotal_supply)

Uber_city_supply_14_group <- group_by(Uber_city_supply_14, RQ_timeslots, City_gap)
uber_city_gap14 <- summarise(Uber_city_supply_14_group, City_Gap = unique(City_gap))

#Plotting gap between demand and supply available as per data for city

text_name_city14 <- c(uber_city_gap14$City_Gap)
Pgap_City14 <- ggplot(na.omit(uber_city_gap14), aes(RQ_timeslots, City_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_city_gap14, aes(RQ_timeslots, City_Gap, label = text_name_city14),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap at City on 14th july")

#Day wise gap 15
Uber_city_supply_15$CityTotal_supply[Uber_city_supply_15$RQ_timeslots == "Early morning"] <- 
  Uber_city_supply15_sum$RQ_timeslot_count[Uber_city_supply15_sum$RQ_timeslots == "Early morning"]

Uber_city_supply_15$CityTotal_supply[Uber_city_supply_15$RQ_timeslots == "Morning"] <- 
  Uber_city_supply15_sum$RQ_timeslot_count[Uber_city_supply15_sum$RQ_timeslots == "Morning"]

Uber_city_supply_15$CityTotal_supply[Uber_city_supply_15$RQ_timeslots == "Noon"] <- 
  Uber_city_supply15_sum$RQ_timeslot_count[Uber_city_supply15_sum$RQ_timeslots == "Noon"]

Uber_city_supply_15$CityTotal_supply[Uber_city_supply_15$RQ_timeslots == "Evening"] <- 
  Uber_city_supply15_sum$RQ_timeslot_count[Uber_city_supply15_sum$RQ_timeslots == "Evening"]

Uber_city_supply_15$CityTotal_supply[Uber_city_supply_15$RQ_timeslots == "Late evening"] <- 
  Uber_city_supply15_sum$RQ_timeslot_count[Uber_city_supply15_sum$RQ_timeslots == "Late evening"]


Uber_city_supply_15$CityTotal_demand[Uber_city_supply_15$RQ_timeslots == "Early morning"] <- 
  Uber_city_Demand15_sum$RQ_timeslot_count[Uber_city_Demand15_sum$RQ_timeslots == "Early morning"]

Uber_city_supply_15$CityTotal_demand[Uber_city_supply_15$RQ_timeslots == "Morning"] <- 
  Uber_city_Demand15_sum$RQ_timeslot_count[Uber_city_Demand15_sum$RQ_timeslots == "Morning"]

Uber_city_supply_15$CityTotal_demand[Uber_city_supply_15$RQ_timeslots == "Noon"] <- 
  Uber_city_Demand15_sum$RQ_timeslot_count[Uber_city_Demand15_sum$RQ_timeslots == "Noon"]

Uber_city_supply_15$CityTotal_demand[Uber_city_supply_15$RQ_timeslots == "Evening"] <- 
  Uber_city_Demand15_sum$RQ_timeslot_count[Uber_city_Demand15_sum$RQ_timeslots == "Evening"]

Uber_city_supply_15$CityTotal_demand[Uber_city_supply_15$RQ_timeslots == "Late evening"] <- 
  Uber_city_Demand15_sum$RQ_timeslot_count[Uber_city_Demand15_sum$RQ_timeslots == "Late evening"]


#Calculating the gap between demand and supply available as per the data for city

Uber_city_supply_15$City_gap <- (Uber_city_supply_15$CityTotal_demand - Uber_city_supply_15$CityTotal_supply)

Uber_city_supply_15_group <- group_by(Uber_city_supply_15, RQ_timeslots, City_gap)
uber_city_gap15 <- summarise(Uber_city_supply_15_group, City_Gap = unique(City_gap))

#Plotting gap between demand and supply available as per data for city

text_name_city15 <- c(uber_city_gap15$City_Gap)
Pgap_City15 <- ggplot(na.omit(uber_city_gap15), aes(RQ_timeslots, City_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_city_gap15, aes(RQ_timeslots, City_Gap, label = text_name_city15),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap at City on 15th july")

######################################################################################################################
# GAP Summary day wise for City                                                                                      #
######################################################################################################################
grid.arrange(Pgap_City11, Pgap_City12,Pgap_City13,Pgap_City14,Pgap_City15, ncol=2, top="Day wise summary Gap plot for - City")

# For pickup point as Airport

#Day wise gap 11
Uber_Air_supply_11$AirTotal_supply[Uber_Air_supply_11$RQ_timeslots == "Early morning"] <- 
  Uber_Air_supply11_sum$RQ_timeslot_count[Uber_Air_supply11_sum$RQ_timeslots == "Early morning"]

Uber_Air_supply_11$AirTotal_supply[Uber_Air_supply_11$RQ_timeslots == "Morning"] <- 
  Uber_Air_supply11_sum$RQ_timeslot_count[Uber_Air_supply11_sum$RQ_timeslots == "Morning"]

Uber_Air_supply_11$AirTotal_supply[Uber_Air_supply_11$RQ_timeslots == "Noon"] <- 
  Uber_Air_supply11_sum$RQ_timeslot_count[Uber_Air_supply11_sum$RQ_timeslots == "Noon"]

Uber_Air_supply_11$AirTotal_supply[Uber_Air_supply_11$RQ_timeslots == "Evening"] <- 
  Uber_Air_supply11_sum$RQ_timeslot_count[Uber_Air_supply11_sum$RQ_timeslots == "Evening"]

Uber_Air_supply_11$AirTotal_supply[Uber_Air_supply_11$RQ_timeslots == "Late evening"] <- 
  Uber_Air_supply11_sum$RQ_timeslot_count[Uber_Air_supply11_sum$RQ_timeslots == "Late evening"]


Uber_Air_supply_11$AirTotal_demand[Uber_Air_supply_11$RQ_timeslots == "Early morning"] <- 
  Uber_Air_Demand11_sum$RQ_timeslot_count[Uber_Air_Demand11_sum$RQ_timeslots == "Early morning"]

Uber_Air_supply_11$AirTotal_demand[Uber_Air_supply_11$RQ_timeslots == "Morning"] <- 
  Uber_Air_Demand11_sum$RQ_timeslot_count[Uber_Air_Demand11_sum$RQ_timeslots == "Morning"]

Uber_Air_supply_11$AirTotal_demand[Uber_Air_supply_11$RQ_timeslots == "Noon"] <- 
  Uber_Air_Demand11_sum$RQ_timeslot_count[Uber_Air_Demand11_sum$RQ_timeslots == "Noon"]

Uber_Air_supply_11$AirTotal_demand[Uber_Air_supply_11$RQ_timeslots == "Evening"] <- 
  Uber_Air_Demand11_sum$RQ_timeslot_count[Uber_Air_Demand11_sum$RQ_timeslots == "Evening"]

Uber_Air_supply_11$AirTotal_demand[Uber_Air_supply_11$RQ_timeslots == "Late evening"] <- 
  Uber_Air_Demand11_sum$RQ_timeslot_count[Uber_Air_Demand11_sum$RQ_timeslots == "Late evening"]


#Calculating the gap between demand and supply available as per the data for Air

Uber_Air_supply_11$Air_gap <- (Uber_Air_supply_11$AirTotal_demand - Uber_Air_supply_11$AirTotal_supply)

Uber_Air_supply_11_group <- group_by(Uber_Air_supply_11, RQ_timeslots, Air_gap)
uber_Air_gap11 <- summarise(Uber_Air_supply_11_group, Air_Gap = unique(Air_gap))

#Plotting gap between demand and supply available as per data for Airport

text_name_Air11 <- c(uber_Air_gap11$Air_Gap)
Pgap_Air11 <- ggplot(na.omit(uber_Air_gap11), aes(RQ_timeslots, Air_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_Air_gap11, aes(RQ_timeslots, Air_Gap, label = text_name_Air11),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap at Air on 11th july")

#Day wise gap 12
Uber_Air_supply_12$AirTotal_supply[Uber_Air_supply_12$RQ_timeslots == "Early morning"] <- 
  Uber_Air_supply12_sum$RQ_timeslot_count[Uber_Air_supply12_sum$RQ_timeslots == "Early morning"]

Uber_Air_supply_12$AirTotal_supply[Uber_Air_supply_12$RQ_timeslots == "Morning"] <- 
  Uber_Air_supply12_sum$RQ_timeslot_count[Uber_Air_supply12_sum$RQ_timeslots == "Morning"]

Uber_Air_supply_12$AirTotal_supply[Uber_Air_supply_12$RQ_timeslots == "Noon"] <- 
  Uber_Air_supply12_sum$RQ_timeslot_count[Uber_Air_supply12_sum$RQ_timeslots == "Noon"]

Uber_Air_supply_12$AirTotal_supply[Uber_Air_supply_12$RQ_timeslots == "Evening"] <- 
  Uber_Air_supply12_sum$RQ_timeslot_count[Uber_Air_supply12_sum$RQ_timeslots == "Evening"]

Uber_Air_supply_12$AirTotal_supply[Uber_Air_supply_12$RQ_timeslots == "Late evening"] <- 
  Uber_Air_supply12_sum$RQ_timeslot_count[Uber_Air_supply12_sum$RQ_timeslots == "Late evening"]


Uber_Air_supply_12$AirTotal_demand[Uber_Air_supply_12$RQ_timeslots == "Early morning"] <- 
  Uber_Air_Demand12_sum$RQ_timeslot_count[Uber_Air_Demand12_sum$RQ_timeslots == "Early morning"]

Uber_Air_supply_12$AirTotal_demand[Uber_Air_supply_12$RQ_timeslots == "Morning"] <- 
  Uber_Air_Demand12_sum$RQ_timeslot_count[Uber_Air_Demand12_sum$RQ_timeslots == "Morning"]

Uber_Air_supply_12$AirTotal_demand[Uber_Air_supply_12$RQ_timeslots == "Noon"] <- 
  Uber_Air_Demand12_sum$RQ_timeslot_count[Uber_Air_Demand12_sum$RQ_timeslots == "Noon"]

Uber_Air_supply_12$AirTotal_demand[Uber_Air_supply_12$RQ_timeslots == "Evening"] <- 
  Uber_Air_Demand12_sum$RQ_timeslot_count[Uber_Air_Demand12_sum$RQ_timeslots == "Evening"]

Uber_Air_supply_12$AirTotal_demand[Uber_Air_supply_12$RQ_timeslots == "Late evening"] <- 
  Uber_Air_Demand12_sum$RQ_timeslot_count[Uber_Air_Demand12_sum$RQ_timeslots == "Late evening"]


#Calculating the gap between demand and supply available as per the data for Airport

Uber_Air_supply_12$Air_gap <- (Uber_Air_supply_12$AirTotal_demand - Uber_Air_supply_12$AirTotal_supply)

Uber_Air_supply_12_group <- group_by(Uber_Air_supply_12, RQ_timeslots, Air_gap)
uber_Air_gap12 <- summarise(Uber_Air_supply_12_group, Air_Gap = unique(Air_gap))

#Plotting gap between demand and supply available as per data for Airport

text_name_Air12 <- c(uber_Air_gap12$Air_Gap)
Pgap_Air12 <- ggplot(na.omit(uber_Air_gap12), aes(RQ_timeslots, Air_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_Air_gap12, aes(RQ_timeslots, Air_Gap, label = text_name_Air12),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap at Air on 12th july")

#Day wise gap 13
Uber_Air_supply_13$AirTotal_supply[Uber_Air_supply_13$RQ_timeslots == "Early morning"] <- 
  Uber_Air_supply13_sum$RQ_timeslot_count[Uber_Air_supply13_sum$RQ_timeslots == "Early morning"]

Uber_Air_supply_13$AirTotal_supply[Uber_Air_supply_13$RQ_timeslots == "Morning"] <- 
  Uber_Air_supply13_sum$RQ_timeslot_count[Uber_Air_supply13_sum$RQ_timeslots == "Morning"]

Uber_Air_supply_13$AirTotal_supply[Uber_Air_supply_13$RQ_timeslots == "Noon"] <- 
  Uber_Air_supply13_sum$RQ_timeslot_count[Uber_Air_supply13_sum$RQ_timeslots == "Noon"]

Uber_Air_supply_13$AirTotal_supply[Uber_Air_supply_13$RQ_timeslots == "Evening"] <- 
  Uber_Air_supply13_sum$RQ_timeslot_count[Uber_Air_supply13_sum$RQ_timeslots == "Evening"]

Uber_Air_supply_13$AirTotal_supply[Uber_Air_supply_13$RQ_timeslots == "Late evening"] <- 
  Uber_Air_supply13_sum$RQ_timeslot_count[Uber_Air_supply13_sum$RQ_timeslots == "Late evening"]


Uber_Air_supply_13$AirTotal_demand[Uber_Air_supply_13$RQ_timeslots == "Early morning"] <- 
  Uber_Air_Demand13_sum$RQ_timeslot_count[Uber_Air_Demand13_sum$RQ_timeslots == "Early morning"]

Uber_Air_supply_13$AirTotal_demand[Uber_Air_supply_13$RQ_timeslots == "Morning"] <- 
  Uber_Air_Demand13_sum$RQ_timeslot_count[Uber_Air_Demand13_sum$RQ_timeslots == "Morning"]

Uber_Air_supply_13$AirTotal_demand[Uber_Air_supply_13$RQ_timeslots == "Noon"] <- 
  Uber_Air_Demand13_sum$RQ_timeslot_count[Uber_Air_Demand13_sum$RQ_timeslots == "Noon"]

Uber_Air_supply_13$AirTotal_demand[Uber_Air_supply_13$RQ_timeslots == "Evening"] <- 
  Uber_Air_Demand13_sum$RQ_timeslot_count[Uber_Air_Demand13_sum$RQ_timeslots == "Evening"]

Uber_Air_supply_13$AirTotal_demand[Uber_Air_supply_13$RQ_timeslots == "Late evening"] <- 
  Uber_Air_Demand13_sum$RQ_timeslot_count[Uber_Air_Demand13_sum$RQ_timeslots == "Late evening"]


#Calculating the gap between demand and supply available as per the data for Airport

Uber_Air_supply_13$Air_gap <- (Uber_Air_supply_13$AirTotal_demand - Uber_Air_supply_13$AirTotal_supply)

Uber_Air_supply_13_group <- group_by(Uber_Air_supply_13, RQ_timeslots, Air_gap)
uber_Air_gap13 <- summarise(Uber_Air_supply_13_group, Air_Gap = unique(Air_gap))

#Plotting gap between demand and supply available as per data for Airport

text_name_Air13 <- c(uber_Air_gap13$Air_Gap)
Pgap_Air13 <- ggplot(na.omit(uber_Air_gap13), aes(RQ_timeslots, Air_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_Air_gap13, aes(RQ_timeslots, Air_Gap, label = text_name_Air13),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap at Air on 13th july")

#Day wise gap 14
Uber_Air_supply_14$AirTotal_supply[Uber_Air_supply_14$RQ_timeslots == "Early morning"] <- 
  Uber_Air_supply14_sum$RQ_timeslot_count[Uber_Air_supply14_sum$RQ_timeslots == "Early morning"]

Uber_Air_supply_14$AirTotal_supply[Uber_Air_supply_14$RQ_timeslots == "Morning"] <- 
  Uber_Air_supply14_sum$RQ_timeslot_count[Uber_Air_supply14_sum$RQ_timeslots == "Morning"]

Uber_Air_supply_14$AirTotal_supply[Uber_Air_supply_14$RQ_timeslots == "Noon"] <- 
  Uber_Air_supply14_sum$RQ_timeslot_count[Uber_Air_supply14_sum$RQ_timeslots == "Noon"]

Uber_Air_supply_14$AirTotal_supply[Uber_Air_supply_14$RQ_timeslots == "Evening"] <- 
  Uber_Air_supply14_sum$RQ_timeslot_count[Uber_Air_supply14_sum$RQ_timeslots == "Evening"]

Uber_Air_supply_14$AirTotal_supply[Uber_Air_supply_14$RQ_timeslots == "Late evening"] <- 
  Uber_Air_supply14_sum$RQ_timeslot_count[Uber_Air_supply14_sum$RQ_timeslots == "Late evening"]


Uber_Air_supply_14$AirTotal_demand[Uber_Air_supply_14$RQ_timeslots == "Early morning"] <- 
  Uber_Air_Demand14_sum$RQ_timeslot_count[Uber_Air_Demand14_sum$RQ_timeslots == "Early morning"]

Uber_Air_supply_14$AirTotal_demand[Uber_Air_supply_14$RQ_timeslots == "Morning"] <- 
  Uber_Air_Demand14_sum$RQ_timeslot_count[Uber_Air_Demand14_sum$RQ_timeslots == "Morning"]

Uber_Air_supply_14$AirTotal_demand[Uber_Air_supply_14$RQ_timeslots == "Noon"] <- 
  Uber_Air_Demand14_sum$RQ_timeslot_count[Uber_Air_Demand14_sum$RQ_timeslots == "Noon"]

Uber_Air_supply_14$AirTotal_demand[Uber_Air_supply_14$RQ_timeslots == "Evening"] <- 
  Uber_Air_Demand14_sum$RQ_timeslot_count[Uber_Air_Demand14_sum$RQ_timeslots == "Evening"]

Uber_Air_supply_14$AirTotal_demand[Uber_Air_supply_14$RQ_timeslots == "Late evening"] <- 
  Uber_Air_Demand14_sum$RQ_timeslot_count[Uber_Air_Demand14_sum$RQ_timeslots == "Late evening"]


#Calculating the gap between demand and supply available as per the data for Airport

Uber_Air_supply_14$Air_gap <- (Uber_Air_supply_14$AirTotal_demand - Uber_Air_supply_14$AirTotal_supply)

Uber_Air_supply_14_group <- group_by(Uber_Air_supply_14, RQ_timeslots, Air_gap)
uber_Air_gap14 <- summarise(Uber_Air_supply_14_group, Air_Gap = unique(Air_gap))

#Plotting gap between demand and supply available as per data for Airport

text_name_Air14 <- c(uber_Air_gap14$Air_Gap)
Pgap_Air14 <- ggplot(na.omit(uber_Air_gap14), aes(RQ_timeslots, Air_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_Air_gap14, aes(RQ_timeslots, Air_Gap, label = text_name_Air14),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap at Air on 14th july")

#Day wise gap 15
Uber_Air_supply_15$AirTotal_supply[Uber_Air_supply_15$RQ_timeslots == "Early morning"] <- 
  Uber_Air_supply15_sum$RQ_timeslot_count[Uber_Air_supply15_sum$RQ_timeslots == "Early morning"]

Uber_Air_supply_15$AirTotal_supply[Uber_Air_supply_15$RQ_timeslots == "Morning"] <- 
  Uber_Air_supply15_sum$RQ_timeslot_count[Uber_Air_supply15_sum$RQ_timeslots == "Morning"]

Uber_Air_supply_15$AirTotal_supply[Uber_Air_supply_15$RQ_timeslots == "Noon"] <- 
  Uber_Air_supply15_sum$RQ_timeslot_count[Uber_Air_supply15_sum$RQ_timeslots == "Noon"]

Uber_Air_supply_15$AirTotal_supply[Uber_Air_supply_15$RQ_timeslots == "Evening"] <- 
  Uber_Air_supply15_sum$RQ_timeslot_count[Uber_Air_supply15_sum$RQ_timeslots == "Evening"]

Uber_Air_supply_15$AirTotal_supply[Uber_Air_supply_15$RQ_timeslots == "Late evening"] <- 
  Uber_Air_supply15_sum$RQ_timeslot_count[Uber_Air_supply15_sum$RQ_timeslots == "Late evening"]


Uber_Air_supply_15$AirTotal_demand[Uber_Air_supply_15$RQ_timeslots == "Early morning"] <- 
  Uber_Air_Demand15_sum$RQ_timeslot_count[Uber_Air_Demand15_sum$RQ_timeslots == "Early morning"]

Uber_Air_supply_15$AirTotal_demand[Uber_Air_supply_15$RQ_timeslots == "Morning"] <- 
  Uber_Air_Demand15_sum$RQ_timeslot_count[Uber_Air_Demand15_sum$RQ_timeslots == "Morning"]

Uber_Air_supply_15$AirTotal_demand[Uber_Air_supply_15$RQ_timeslots == "Noon"] <- 
  Uber_Air_Demand15_sum$RQ_timeslot_count[Uber_Air_Demand15_sum$RQ_timeslots == "Noon"]

Uber_Air_supply_15$AirTotal_demand[Uber_Air_supply_15$RQ_timeslots == "Evening"] <- 
  Uber_Air_Demand15_sum$RQ_timeslot_count[Uber_Air_Demand15_sum$RQ_timeslots == "Evening"]

Uber_Air_supply_15$AirTotal_demand[Uber_Air_supply_15$RQ_timeslots == "Late evening"] <- 
  Uber_Air_Demand15_sum$RQ_timeslot_count[Uber_Air_Demand15_sum$RQ_timeslots == "Late evening"]


#Calculating the gap between demand and supply available as per the data for Airport

Uber_Air_supply_15$Air_gap <- (Uber_Air_supply_15$AirTotal_demand - Uber_Air_supply_15$AirTotal_supply)

Uber_Air_supply_15_group <- group_by(Uber_Air_supply_15, RQ_timeslots, Air_gap)
uber_Air_gap15 <- summarise(Uber_Air_supply_15_group, Air_Gap = unique(Air_gap))

#Plotting gap between demand and supply available as per data for Airport

text_name_Air15 <- c(uber_Air_gap15$Air_Gap)
Pgap_Air15 <- ggplot(na.omit(uber_Air_gap15), aes(RQ_timeslots, Air_Gap, group = 1))+ geom_point() +geom_line() +
  geom_text(data= uber_Air_gap15, aes(RQ_timeslots, Air_Gap, label = text_name_Air15),size=4, hjust = 1.3, vjust = 1.3)+
  ggtitle("Demand - Supply gap at Air on 15th july")

############################################################################################################################
# GAP Summary day wise for Airport                                                                                         #
############################################################################################################################
grid.arrange(Pgap_Air11, Pgap_Air12,Pgap_Air13,Pgap_Air14,Pgap_Air15, ncol=2, top="Day wise summary Gap plot for - Air")

###########################################################################################################################
# Calculating actual supply available                                                                                     #
###########################################################################################################################
#Subsetting data to calculate actual supply at Airport & city from trip completed status 
uber_Actual_City_supply   <- subset(uber_data, (Status == "Trip Completed" | Status == "Cancelled") & Pickup.point == "City")
uber_Actual_Air_supply    <- subset(uber_data, (Status == "Trip Completed" |Status == "Cancelled") & Pickup.point == "Airport")

uber_Actual_City_supply_grp       <- group_by(uber_Actual_City_supply, RQ_timeslots)
Uber_Actual_City_supply_sum       <- summarise(uber_Actual_City_supply_grp, RQ_timeslot_count =length(RQ_timeslots))

uber_Actual_Air_supply_grp       <- group_by(uber_Actual_Air_supply, RQ_timeslots)
Uber_Actual_Air_supply_sum       <- summarise(uber_Actual_Air_supply_grp, RQ_timeslot_count =length(RQ_timeslots))


##########################################################################################################################
#Calculating percentage of cancellation happened from total available                                                    #
##########################################################################################################################

# For City
Uber_Actual_City_supply_sum$percent_CA[Uber_Actual_City_supply_sum$RQ_timeslots == "Early morning"] <- 
 round(( uber_CAcity_sum$RQ_timeslot_count[uber_CAcity_sum$RQ_timeslots == "Early morning"]/
    Uber_Actual_City_supply_sum$RQ_timeslot_count[Uber_Actual_City_supply_sum$RQ_timeslots == "Early morning"]) * 100, 2)

Uber_Actual_City_supply_sum$percent_CA[Uber_Actual_City_supply_sum$RQ_timeslots == "Morning"] <- 
  round(( uber_CAcity_sum$RQ_timeslot_count[uber_CAcity_sum$RQ_timeslots == "Morning"]/
      Uber_Actual_City_supply_sum$RQ_timeslot_count[Uber_Actual_City_supply_sum$RQ_timeslots == "Morning"]) * 100, 2)

Uber_Actual_City_supply_sum$percent_CA[Uber_Actual_City_supply_sum$RQ_timeslots == "Noon"] <- 
  round(( uber_CAcity_sum$RQ_timeslot_count[uber_CAcity_sum$RQ_timeslots == "Noon"]/
      Uber_Actual_City_supply_sum$RQ_timeslot_count[Uber_Actual_City_supply_sum$RQ_timeslots == "Noon"]) * 100, 2)

Uber_Actual_City_supply_sum$percent_CA[Uber_Actual_City_supply_sum$RQ_timeslots == "Evening"] <- 
  round(( uber_CAcity_sum$RQ_timeslot_count[uber_CAcity_sum$RQ_timeslots == "Evening"]/
      Uber_Actual_City_supply_sum$RQ_timeslot_count[Uber_Actual_City_supply_sum$RQ_timeslots == "Evening"]) * 100, 2)

Uber_Actual_City_supply_sum$percent_CA[Uber_Actual_City_supply_sum$RQ_timeslots == "Late evening"] <- 
 round(( uber_CAcity_sum$RQ_timeslot_count[uber_CAcity_sum$RQ_timeslots == "Late evening"]/
      Uber_Actual_City_supply_sum$RQ_timeslot_count[Uber_Actual_City_supply_sum$RQ_timeslots == "Late evening"]) * 100,2)

#Plotting percentage of cancellations happening in City at different time slots
text_name_per_city <- c(Uber_Actual_City_supply_sum$percent_CA)
P_percent_city <- ggplot(Uber_Actual_City_supply_sum, aes(RQ_timeslots, percent_CA, group = 1)) + geom_point()+ geom_line()+
  scale_y_continuous(labels = function(x){ paste0(x, "%") }) + ggtitle("Percentage of cancellations in City") +
  geom_text(data= Uber_Actual_City_supply_sum, aes(RQ_timeslots, percent_CA, label = paste(text_name_per_city, "%",sep = "" )),size=4, hjust = .9, vjust = 1.0)

#for Airport
Uber_Actual_Air_supply_sum$percent_CA[Uber_Actual_Air_supply_sum$RQ_timeslots == "Morning"] <- 
  round(( uber_CAair_sum$RQ_timeslot_count[uber_CAair_sum$RQ_timeslots == "Morning"]/
            Uber_Actual_Air_supply_sum$RQ_timeslot_count[Uber_Actual_Air_supply_sum$RQ_timeslots == "Morning"]) * 100, 2)

Uber_Actual_Air_supply_sum$percent_CA[Uber_Actual_Air_supply_sum$RQ_timeslots == "Noon"] <- 
  round(( uber_CAair_sum$RQ_timeslot_count[uber_CAair_sum$RQ_timeslots == "Noon"]/
            Uber_Actual_Air_supply_sum$RQ_timeslot_count[Uber_Actual_Air_supply_sum$RQ_timeslots == "Noon"]) * 100, 2)

Uber_Actual_Air_supply_sum$percent_CA[Uber_Actual_Air_supply_sum$RQ_timeslots == "Evening"] <- 
  round(( uber_CAair_sum$RQ_timeslot_count[uber_CAair_sum$RQ_timeslots == "Evening"]/
            Uber_Actual_Air_supply_sum$RQ_timeslot_count[Uber_Actual_Air_supply_sum$RQ_timeslots == "Evening"]) * 100, 2)

#Zero cancellations happening during Early morning and Late evenings at Airport, so assigning zero to percentage field for plotting
Uber_Actual_Air_supply_sum$percent_CA [which(is.na(Uber_Actual_Air_supply_sum$percent_CA))] <- 0

#Plotting percentage of cancellations happening in Airport at different time slots
text_name_per_Air <- c(Uber_Actual_Air_supply_sum$percent_CA)
P_percent_Air <- ggplot(Uber_Actual_Air_supply_sum, aes(RQ_timeslots, percent_CA, group = 1)) + geom_point()+ geom_line()+
  scale_y_continuous(labels = function(x){ paste0(x, "%") }) + ggtitle("Percentage of cancellations in Airport") +
  geom_text(data= Uber_Actual_Air_supply_sum, aes(RQ_timeslots, percent_CA, label = paste(text_name_per_Air, "%",sep = "" )),size=4, hjust = 1.3, vjust = 1.0)

grid.arrange(P_percent_Air, P_percent_city, ncol=2, top="Percentage of cancellations happening during timeslots")

##########################################################################################################################
#Calculating percentage of non-availability of cars happened from total available                                        #
##########################################################################################################################

# For City
Uber_city_Demand_sum$percent_NCA[Uber_city_Demand_sum$RQ_timeslots == "Early morning"] <- 
  round(( uber_NCAcity_sum$RQ_timeslot_count[uber_NCAcity_sum$RQ_timeslots == "Early morning"]/
            Uber_city_Demand_sum$RQ_timeslot_count[Uber_city_Demand_sum$RQ_timeslots == "Early morning"]) * 100, 2)

Uber_city_Demand_sum$percent_NCA[Uber_city_Demand_sum$RQ_timeslots == "Morning"] <- 
  round(( uber_NCAcity_sum$RQ_timeslot_count[uber_NCAcity_sum$RQ_timeslots == "Morning"]/
            Uber_city_Demand_sum$RQ_timeslot_count[Uber_city_Demand_sum$RQ_timeslots == "Morning"]) * 100, 2)

Uber_city_Demand_sum$percent_NCA[Uber_city_Demand_sum$RQ_timeslots == "Noon"] <- 
  round(( uber_NCAcity_sum$RQ_timeslot_count[uber_NCAcity_sum$RQ_timeslots == "Noon"]/
            Uber_city_Demand_sum$RQ_timeslot_count[Uber_city_Demand_sum$RQ_timeslots == "Noon"]) * 100, 2)

Uber_city_Demand_sum$percent_NCA[Uber_city_Demand_sum$RQ_timeslots == "Evening"] <- 
  round(( uber_NCAcity_sum$RQ_timeslot_count[uber_NCAcity_sum$RQ_timeslots == "Evening"]/
            Uber_city_Demand_sum$RQ_timeslot_count[Uber_city_Demand_sum$RQ_timeslots == "Evening"]) * 100, 2)

Uber_city_Demand_sum$percent_NCA[Uber_city_Demand_sum$RQ_timeslots == "Late evening"] <- 
  round(( uber_NCAcity_sum$RQ_timeslot_count[uber_NCAcity_sum$RQ_timeslots == "Late evening"]/
            Uber_city_Demand_sum$RQ_timeslot_count[Uber_city_Demand_sum$RQ_timeslots == "Late evening"]) * 100,2)

#Plotting percentage of cancellations happening in City at different time slots
text_NCA_per_city <- c(Uber_city_Demand_sum$percent_NCA)
P_percent_NCAcity <- ggplot(Uber_city_Demand_sum, aes(RQ_timeslots, percent_NCA, group = 1)) + geom_point()+ geom_line()+
  scale_y_continuous(labels = function(x){ paste0(x, "%") }) + ggtitle("Percentage of non-availabilty in City") +
  geom_text(data= Uber_city_Demand_sum, aes(RQ_timeslots, percent_NCA, label = paste(text_NCA_per_city, "%",sep = "" )),size=4, hjust = .7, vjust = 1.0)
Uber_Air_Demand_sum$percent_NCA[Uber_Air_Demand_sum$RQ_timeslots == "Morning"] <- 
  round(( uber_NCAair_sum$RQ_timeslot_count[uber_NCAair_sum$RQ_timeslots == "Morning"]/
            Uber_Air_Demand_sum$RQ_timeslot_count[Uber_Air_Demand_sum$RQ_timeslots == "Morning"]) * 100, 2)

Uber_Air_Demand_sum$percent_NCA[Uber_Air_Demand_sum$RQ_timeslots == "Noon"] <- 
  round(( uber_NCAair_sum$RQ_timeslot_count[uber_NCAair_sum$RQ_timeslots == "Noon"]/
            Uber_Air_Demand_sum$RQ_timeslot_count[Uber_Air_Demand_sum$RQ_timeslots == "Noon"]) * 100, 2)

Uber_Air_Demand_sum$percent_NCA[Uber_Air_Demand_sum$RQ_timeslots == "Evening"] <- 
  round(( uber_NCAair_sum$RQ_timeslot_count[uber_NCAair_sum$RQ_timeslots == "Evening"]/
            Uber_Air_Demand_sum$RQ_timeslot_count[Uber_Air_Demand_sum$RQ_timeslots == "Evening"]) * 100, 2)

#Zero cancellations happening during Early morning and Late evenings at Airport, so assigning zero to percentage field for plotting
Uber_Air_Demand_sum$percent_NCA [which(is.na(Uber_Air_Demand_sum$percent_NCA))] <- 0

#Plotting percentage of cancellations happening in Airport at different time slots
text_NCA_per_Air <- c(Uber_Air_Demand_sum$percent_NCA)
P_percent_NCAAir <- ggplot(Uber_Air_Demand_sum, aes(RQ_timeslots, percent_NCA, group = 1)) + geom_point()+ geom_line()+
  scale_y_continuous(labels = function(x){ paste0(x, "%") }) + ggtitle("Percentage of non-availability in Airport") +
  geom_text(data= Uber_Air_Demand_sum, aes(RQ_timeslots, percent_NCA, label = paste(text_NCA_per_Air, "%",sep = "" )),size=4, hjust = 1.3, vjust = 1.0)

grid.arrange(P_percent_NCAAir, P_percent_NCAcity, ncol=2, top="Percentage of non-availability of cars happening during timeslots")

#########################################################################################################################
# Cancellation Vs Non-availability in city                                                                              #
#########################################################################################################################
grid.arrange(P_percent_city, P_percent_NCAcity, ncol=2, top="Percentage of Cancellation Vs non-availability")

#########################################################################################################################
# Cancellation Vs Non-availability in Airport                                                                           #
#########################################################################################################################

grid.arrange(P_percent_Air, P_percent_NCAAir, ncol=2, top="Percentage of Cancellation Vs non-availability")


